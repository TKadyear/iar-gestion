# iar-gestion
## Links

  - Demo : []()

## Clona este repositorio
      ```bash
# Clona este repositorio
$ git clone https://github.com/TKadyear/iar-gestion.git

# Entra en la carpeta
$ cd iar-gestion

# Instala las dependencias
$ npm install

# Inicia el servidor de desarrollo
$ npm run dev
```
Para ver el servidor de producción, ejecuta los siguientes comandos:
```bash
# Para preparar los documentos para producción:
$ npm run build

# Inicia el servidor de desarrollo
$ npm run preview
```
## Autora
  - Github - [TKadyear](https://github.com/TKadyear)
  - Linkedin - [Tamara Kadyear Saber](https://www.linkedin.com/in/tamara-kadyear-saber/)
